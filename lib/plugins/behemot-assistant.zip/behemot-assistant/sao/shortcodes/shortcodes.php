<?php
if(!defined('ABSPATH')) exit;

define('SAO_DUMMY_PERSON', __( BEHEMOTH_ASSISTANT_PLUGIN_URL.'sao/assets/avatar.png','sao'));
define('SAO_DUMMY_LOGO', __( BEHEMOTH_ASSISTANT_PLUGIN_URL.'sao/assets/behlogo.png','sao'));
define('SAO_DUMMY_IMG', __( BEHEMOTH_ASSISTANT_PLUGIN_URL.'sao/assets/reptile.png','sao'));
define('SAO_DUMMY_GALL', __( BEHEMOTH_ASSISTANT_PLUGIN_URL.'sao/assets/defbg.png','sao'));

function sao_starter_content($did=''){
  $return = '';
  $services = '<li class="service-list">
              <i class="custom-icon fas fa-magic"></i>
              <div class="service-title">Top Notch Design</div>
              <div class="service-content">
                <p>Afrikato akuzativo ar fin, ok veka getto matematiko for.
                Ses jena certa ng, ekkrio bedaŭrinde nk kie,
                sh afro subjunkcio internacia ene</p>
              </div>
              </li>
              <li class="service-list">
                <i class="custom-icon fa fa-mobile"></i>
                <div class="service-title">Mobile Friendly</div>
                <div class="service-content">
                  <p>Afrikato akuzativo ar fin, ok veka getto matematiko for.
                  Ses jena certa ng, ekkrio bedaŭrinde nk kie,
                  sh afro subjunkcio internacia ene</p>
                </div>
                </li>
                <li class="service-list">
                  <i class="custom-icon fa fa-cogs"></i>
                  <div class="service-title">Highly Customizable</div>
                  <div class="service-content">
                    <p>Afrikato akuzativo ar fin, ok veka getto matematiko for.
                    Ses jena certa ng, ekkrio bedaŭrinde nk kie,
                    sh afro subjunkcio internacia ene</p>
                  </div>
                  </li>';

  $team ='<div class="team-wrap">
     <article class="material-card">
         <h2>
             <span>John Doe</span>
             <strong>
                 CEO
             </strong>
         </h2>
         <div class="mc-content">
             <div class="img-container">
                 <img class="img-responsive" src="'. SAO_DUMMY_PERSON .'" alt="team member">
             </div>
             <div class="mc-description">
             Ant ec komplika prepozitivo,
             do kurta sjoro decimaloj sin,
             onjo vic latina per aj. An sis
             kombi resti negativaj, halt piedpilko mis ot.
             </div>
         </div>
         <a class="mc-btn-action">
             <i class="fas fa-bars"></i>
         </a>
         <div class="mc-footer">
           <a class="fab fa-facebook fa-3x"></a>
           <a class="fab fa-twitter-square fa-3x"></a>
           <a class="fab fa-pinterest-square fa-3x"></a>
           <a class="fab fa-linkedin fa-3x"></a>
         </div>
     </article>
  </div>
  <div class="team-wrap">
     <article class="material-card">
         <h2>
             <span>John Doe</span>
             <strong>
                 CEO
             </strong>
         </h2>
         <div class="mc-content">
             <div class="img-container">
                 <img class="img-responsive" src="'. SAO_DUMMY_PERSON .'" alt="team member">
             </div>
             <div class="mc-description">
             Ant ec komplika prepozitivo,
             do kurta sjoro decimaloj sin,
             onjo vic latina per aj. An sis
             kombi resti negativaj, halt piedpilko mis ot.
             </div>
         </div>
         <a class="mc-btn-action">
             <i class="fas fa-bars"></i>
         </a>
         <div class="mc-footer">
           <a class="fab fa-facebook fa-3x"></a>
           <a class="fab fa-twitter-square fa-3x"></a>
           <a class="fab fa-pinterest-square fa-3x"></a>
           <a class="fab fa-linkedin fa-3x"></a>
         </div>
     </article>
  </div>
  <div class="team-wrap">
     <article class="material-card">
         <h2>
             <span>John Doe</span>
             <strong>
                 CEO
             </strong>
         </h2>
         <div class="mc-content">
             <div class="img-container">
                 <img class="img-responsive" src="'. SAO_DUMMY_PERSON .'" alt="team member">
             </div>
             <div class="mc-description">
             Ant ec komplika prepozitivo,
             do kurta sjoro decimaloj sin,
             onjo vic latina per aj. An sis
             kombi resti negativaj, halt piedpilko mis ot.
             </div>
         </div>
         <a class="mc-btn-action">
             <i class="fas fa-bars"></i>
         </a>
         <div class="mc-footer">
           <a class="fab fa-facebook fa-3x"></a>
           <a class="fab fa-twitter-square fa-3x"></a>
           <a class="fab fa-pinterest-square fa-3x"></a>
           <a class="fab fa-linkedin fa-3x"></a>
         </div>
     </article>
  </div>';

  $slider = '<div id="slider--el-1" class="slider--el slider--el-dummy anim-4parts active">
    <div class="slider--el-bg">
      <div class="part top left"></div>
      <div class="part top right"></div>
      <div class="part bot left"></div>
      <div class="part bot right"></div>
    </div>
    <div class="slider--el-content">
      <div class="slider--el-content-inner">
        <h2 class="slider--el-heading first-slider-header">Slider 1</h2>
        <p class="slider--el-paragraph first-slider-text">
          Lorem ipsum dolor sit amet, et novum molestie pro,
          nam fabellas accusata laboramus ut. Nonumy percipitur vix ne,
          impetus sanctus laboramus ad sea. Alterum reprehendunt ut pro, usu ei magna tantas.
        </p>
        <a class="btn slider-button first-slider-button" href="">Button</a>
      </div>
    </div>
  </div>
  <span class="slider--control left"></span>
  <span class="slider--control right"></span>';

  $testimonials = '
  <li>
    <div class="image-testimonial wow fadeInLeft" data-wow-delay="0s">
     <img src="'. SAO_DUMMY_PERSON .'" alt="Testimonials Image">
    </div>
    <div class="testimonial-content wow fadeInRight" data-wow-delay="0s"><q class="testimonial-quote" style="">Thank you so much for everything</q></div>
    <div class="testimonial-content-header"><h2>Jane Doe</h2></div>
  </li>
  <li>
    <div class="image-testimonial wow fadeInLeft" data-wow-delay="0s">
     <img src="'. SAO_DUMMY_PERSON .'" alt="Testimonials Image">
    </div>
    <div class="testimonial-content wow fadeInRight" data-wow-delay="0s"><q class="testimonial-quote" style="">I am going to recommend you highly with my crystal lover friends!</q></div>
    <div class="testimonial-content-header"><h2>John Doe</h2></div>
  </li>';

  $partners ='
  <li>
   <div class="partners-image wow fadeInLeft" data-wow-delay="0s">
    <img src="'. SAO_DUMMY_LOGO .'" alt="Clients Logo 1">
   </div>
  </li>
  <li>
   <div class="partners-image wow fadeInLeft" data-wow-delay="0s">
    <img src="'. SAO_DUMMY_LOGO .'" alt="Clients Logo 2">
   </div>
  </li>
  <li>
   <div class="partners-image wow fadeInLeft" data-wow-delay="0s">
    <img src="'. SAO_DUMMY_LOGO .'" alt="Clients Logo 3">
   </div>
  </li>';

  $contactItems = '
  <div class="contact-us-item item-1">
    <i class="item-icon fas fa-map-marker"></i>
    <p class="address">123 Main Street</p>
  </div>
  <div class="contact-us-item item-2">
    <i class="item-icon fas fa-phone"></i>
    <p class="phone">0800 123 456</p>
  </div>
  <div class="contact-us-item item-3">
    <i class="item-icon far fa-envelope-open"></i>
    <p class="email">fictional@gmail.com</p>
  </div>';

  $content = '
  <div class="content-section content-section-with-arrow" style="background-color:aqua">
    <div class="content-container wow fadeInRight imgright">
        <div class="content-image-imgcol">
          <img src="'. SAO_DUMMY_GALL .'" alt="Features Image">
        </div>
        <div class="content-image-textcol">
            <h2>Liber interesset</h2>
            <p>Liber interesset quo no, ut sint fabulas maiorum sed, sed ad vituperata necessitatibus.
            Sit consul consetetur no, ex perpetua senserit intellegam vel. His altera ponderum ex, an quo lorem adipisci</p>
        </div>
    </div>
	</div>
  <div class="content-section content-section-no-arrow" style="background-color:white">
    <div class="content-container wow fadeInRight imgleft">
        <div class="content-image-imgcol">
          <img src="'. SAO_DUMMY_GALL .'" alt="Features Image">
        </div>
        <div class="content-image-textcol">
            <h2>Liber interesset</h2>
            <p>Liber interesset quo no, ut sint fabulas maiorum sed, sed ad vituperata necessitatibus.
            Sit consul consetetur no, ex perpetua senserit intellegam vel. His altera ponderum ex, an quo lorem adipisci</p>
        </div>
    </div>
	</div>';

  $gallery = '
  <div class="m-p-g">
      <div class="m-p-g__thumbs" data-google-image-layout data-max-height="300">
        <img src="'. SAO_DUMMY_GALL .'" data-full="'. SAO_DUMMY_GALL .'" class="m-p-g__thumbs-img" data-height="300" data-width="300" alt="Gallery Image"/>
        <img src="'. SAO_DUMMY_GALL .'" data-full="'. SAO_DUMMY_GALL .'" class="m-p-g__thumbs-img" data-height="300" data-width="300" alt="Gallery Image"/>
        <img src="'. SAO_DUMMY_GALL .'" data-full="'. SAO_DUMMY_GALL .'" class="m-p-g__thumbs-img" data-height="300" data-width="300" alt="Gallery Image"/>
        <img src="'. SAO_DUMMY_GALL .'" data-full="'. SAO_DUMMY_GALL .'" class="m-p-g__thumbs-img" data-height="300" data-width="300" alt="Gallery Image"/>
     </div>
     <div class="m-p-g__fullscreen"></div>
   </div>';

  $projects = '
  <div class="project-wrap">
     <article class="material-card">
        <h2>
            <span>Deleniti vivendum</span>
        </h2>
        <div class="mc-content">
            <div class="img-container">
                <img class="img-responsive" src="'. SAO_DUMMY_GALL .'" alt="Project Image">
            </div>
            <div class="mc-description">Sint vidit putant nec at, ne mea nulla animal,
            docendi noluisse in vix.
            Deleniti vivendum efficiendi pri ex.
            Eos euismod explicari theophrastus ea,
            stet scripta gubergren pri in.</div>
        </div>
        <a class="mc-btn-action">
            <i class="fas fa-bars"></i>
        </a>
        <div class="mc-footer">
          <a class="btn">Read More</a>
        </div>
    </article>
  </div>
  <div class="project-wrap">
     <article class="material-card">
        <h2>
            <span>Deleniti vivendum</span>
        </h2>
        <div class="mc-content">
            <div class="img-container">
                <img class="img-responsive" src="'. SAO_DUMMY_GALL .'" alt="Project Image">
            </div>
            <div class="mc-description">Sint vidit putant nec at, ne mea nulla animal,
            docendi noluisse in vix.
            Deleniti vivendum efficiendi pri ex.
            Eos euismod explicari theophrastus ea,
            stet scripta gubergren pri in.</div>
        </div>
        <a class="mc-btn-action">
            <i class="fas fa-bars"></i>
        </a>
        <div class="mc-footer">
          <a class="btn">Read More</a>
        </div>
    </article>
  </div>
  <div class="project-wrap">
     <article class="material-card">
        <h2>
            <span>Deleniti vivendum</span>
        </h2>
        <div class="mc-content">
            <div class="img-container">
                <img class="img-responsive" src="'. SAO_DUMMY_GALL .'" alt="Project Image">
            </div>
            <div class="mc-description">Sint vidit putant nec at, ne mea nulla animal,
            docendi noluisse in vix.
            Deleniti vivendum efficiendi pri ex.
            Eos euismod explicari theophrastus ea,
            stet scripta gubergren pri in.</div>
        </div>
        <a class="mc-btn-action">
            <i class="fas fa-bars"></i>
        </a>
        <div class="mc-footer">
          <a class="btn">Read More</a>
        </div>
    </article>
  </div>
  ';
  $footer_info = '
  <p>
		<i class="fas fa-envelope-open" aria-hidden="true"></i>
		email:<a href="mailto:email" class="foot-email">fictional@gmail.com</a>
	</p>
	<p>
		<i class="fa fa-phone" aria-hidden="true"></i>
		phone:<a href="tel:0800999888" class="foot-phone"> 0800999888</a>
	</p>
  ';

                  if($did == 1){
                    $return = $services;
                  } elseif ($did == 2){
                    $return = $team;
                  } elseif ($did == 3){
                    $return = $slider;
                  } elseif ($did == 4){
                    $return = $testimonials;
                  } elseif ($did == 5){
                    $return = $partners;
                  } elseif ($did == 6){
                    $return = $contactItems;
                  } elseif ($did == 7){
                    $return = $content;
                  } elseif ($did == 8){
                    $return = $gallery;
                  } elseif ($did == 9){
                    $return = $projects;
                  } elseif ($did == 10){
                    $return = $aboutus;
                  } elseif ($did == 11){
                    $return = $footer_info;
                  }

                  return $return;
}

function sao_data($attrs){
  $output = '';
  $pull_quote_attrs = shortcode_atts(array(
    'did' => 1
  ), $attrs);
  $did = wp_kses_post($pull_quote_attrs['did']);

  $output = sao_starter_content($did);
  return $output;
}

add_shortcode('sao_dummy_data','sao_data');

function sao_contact_form( $attrs = array()){
  $atts = shortcode_atts (
    array (
      'shortcode' => ''
    ), $attrs);

    $contact_form_sc = get_theme_mod('contact_form_shortcode', '');
    if($atts['shortcode']){
      $contact_form_sc = "[" . html_entity_decode(html_entity_decode($atts['shortcode'])) . "]";
    }
    ob_start();
    if ( $contact_form_sc != ""){
        echo do_shortcode($contact_form_sc);
    } else {
      echo '<p style="text-align:center;color:#ababab">' . __('Contact form will be displayed here. To activate it you have to set the "contact form shortcode" parameter in Customizer.',
              'sao') . '</p>';
    }

    $content = ob_get_contents();
    ob_end_clean();

    return $content;
}
add_shortcode('sao_contact_form','sao_contact_form');
 ?>
