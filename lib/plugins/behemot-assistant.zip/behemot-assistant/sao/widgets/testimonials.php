<?php
class sao_customizer_testimonial_widget extends WP_Widget {

    function __construct() {
        $widget_ops = array('classname' => 'sao-customizer-testimonial',
            'description' => 'Show your testimonial');
        parent::__construct('sao_customizer_testimonial_widget', __('sao : Testimonial Widget','sao'), $widget_ops);
    }

    function widget($args, $instance) {
        extract($args);
        // widget content
        echo $before_widget;

        $name= isset($instance['name'])?$instance['name']:__('Name','sao');
        $authpic = isset($instance['authpic'])?$instance['authpic']:'';
        $quote = isset($instance['quote'])?$instance['quote']:'';
				$namecolor = isset($instance['namecolor'])?$instance['namecolor']:'#000';
				$quotecolor = isset($instance['quotecolor'])?$instance['quotecolor']:'#000';
?>

        <li><div class="image-testimonial wow fadeInLeft" data-wow-delay="0s">
          <?php  if($authpic!=''){ ?>
           <img src="<?php echo $authpic; ?>">
           <?php } ?>
          </div>
          <div class="testimonial-content wow fadeInRight" data-wow-delay="0s"><q class="testimonial-quote" style="color:<?php echo $quotecolor; ?>"><?php echo $quote; ?></q></div>
  				<div class="testimonial-content-header"><h2 style="color:<?php echo $namecolor; ?>"><?php echo apply_filters('widget_title', $name ); ?></h2></div>
        </li>

<?php
        echo $after_widget;

    }

    function update($new_instance, $old_instance) {
        $instance = $old_instance;
        $instance['authpic'] = $new_instance['authpic'];
        $instance['name'] = strip_tags( $new_instance['name'] );
        $instance['quote'] = $new_instance['quote'];
				$instance['namecolor'] = $new_instance['namecolor'];
				$instance['quotecolor'] = $new_instance['quotecolor'];
        return $instance;
    }

    function form($instance) {
        if( $instance) {
        $name = esc_attr($instance['name']);
        $authpic = strip_tags($instance['authpic']);
        $quote = $instance['quote'];
				$namecolor = $instance['namecolor'];
				$quotecolor = $instance['quotecolor'];
    } else {
        $name = '';
        $authpic = '';
        $quote = '';
				$namecolor = '#000';
				$quotecolor = '#000';
    }
    ?>
        <div class="clearfix"></div>
        <label for="<?php echo $this->get_field_id('authpic'); ?>"><?php _e('Author Image','sao'); ?></label>
                <?php
            if ( isset($instance['authpic']) && $instance['authpic'] != '' ) :
                echo '<img class="custom_media_image" src="' . $instance['authpic'] . '" style="margin:0;padding:0;max-width:100px;float:left;display:inline-block" /><br />';
            endif;
        ?>
        <input type="text" class="widefat custom_media_url" name="<?php echo $this->get_field_name('authpic'); ?>" id="<?php echo $this->get_field_id('authpic'); ?>" value="<?php  echo $authpic; ?>" style="margin-top:5px;">
        <input type="button" class="button button-primary custom_media_button" id="<?php echo $this->get_field_id('authpic'); ?>_button" name="<?php echo $this->get_field_name('authpic'); ?>" value="Upload Image" style="margin-top:5px;" />


        <label for="<?php echo $this->get_field_id('name'); ?>"><?php _e('Author Name','sao'); ?>
        </label>
          <textarea  name="<?php echo $this->get_field_name('name'); ?>" id="<?php echo $this->get_field_id('name'); ?>"  class="widefat" ><?php echo $name; ?></textarea>
				<p>
					<label for="<?php echo $this->get_field_id( 'namecolor' ); ?>" style="display:block;"><?php _e( 'Name Color','sao' ); ?></label>
					<input class="widefat color-picker" id="<?php echo $this->get_field_id( 'namecolor' ); ?>" name="<?php echo $this->get_field_name( 'namecolor' ); ?>" type="text" value="<?php echo esc_attr( $namecolor ); ?>" />
				</p>

        <label for="<?php echo $this->get_field_id('quote'); ?>"><?php _e('Quote','sao'); ?></label>
        <textarea  name="<?php echo $this->get_field_name('quote'); ?>" id="<?php echo $this->get_field_id('quote'); ?>"  class="widefat" ><?php echo $quote; ?></textarea>
				<p>
					<label for="<?php echo $this->get_field_id( 'quotecolor' ); ?>" style="display:block;"><?php _e( 'Quote Color','sao' ); ?></label>
					<input class="widefat color-picker" id="<?php echo $this->get_field_id( 'quotecolor' ); ?>" name="<?php echo $this->get_field_name( 'quotecolor' ); ?>" type="text" value="<?php echo esc_attr( $quotecolor ); ?>" />
				</p>
        <?php
    }
}
