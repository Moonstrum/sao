<?php
class sao_customizer_services_widget extends WP_Widget{
	function __construct(){
		$widget_options = array(
			'classname'   => 'sao_customizer_services',
			'description' => 'Show your services'
		);
		parent::__construct('sao_customizer_services_widget', __('sao: Service Widget', 'sao'), $widget_options);
	}

	function widget( $args, $instance ){
		extract( $args );

		echo $before_widget;

		$text = isset($instance['text'])?$instance['text']:__('Write your description','sao');
    $title = isset($instance['title'])?$instance['title']:__('New Title','sao');
    $fontaws = isset($instance['fontaws'])?$instance['fontaws']:'fab fa-fly';
    $iconcolor = isset($instance['iconcolor'])?$instance['iconcolor']:'#D4B068';
		?>
		<li class="service-list">
			<div class="service-icon">
				<i style="color:<?php echo $iconcolor; ?>" class="custom-icon <?php echo $fontaws; ?>"></i>
			</div>
			<h4 class="service-title"><?php echo apply_filters('widget_title', $title); ?></h4>
			<div class="service-content"><p><?php echo $text; ?></p></div>
		</li>

	<?php

			echo $after_widget;
	}

	function update($new_instance, $old_instance) {
		$instance = $old_instance;
	 $instance['fontaws'] = $new_instance['fontaws'];
	 $instance['title']   = strip_tags( $new_instance['title'] );
	 $instance['text']    = $new_instance['text'];
	 $instance['iconcolor']  = $new_instance['iconcolor'];
	 return $instance;
	}
	//Widget Backend
	function form($instance) {
         if( $instance) {
        $title = esc_attr($instance['title']);
        $fontaws = esc_attr($instance['fontaws']);
        $text = $instance['text'];
        $iconcolor = $instance['iconcolor'];

    } else {
        $title = '';
        $fontaws = 'fab fa-fly';
        $text = '';
        $iconcolor = '#D4B068';
    }
		?>
		<div class="clearfix"></div>
        <p>
        <label for="<?php echo $this->get_field_id('title'); ?>"><?php _e('Title','sao'); ?></label>
        <input type="text" class="widefat" name="<?php echo $this->get_field_name('title'); ?>" id="<?php echo $this->get_field_id('title'); ?>" value="<?php  echo $title; ?>" style="margin-top:5px;">
        </p>
        <p>
        <label for="<?php echo $this->get_field_id('text'); ?>"><?php _e('Description','sao'); ?></label>
        <textarea  name="<?php echo $this->get_field_name('text'); ?>" id="<?php echo $this->get_field_id('text'); ?>" maxlength="150" class="widefat" ><?php echo $text; ?></textarea>
        </p>
       <p>
        <label for="<?php echo $this->get_field_id('fontaws'); ?>"><?php _e('Font Awesome Icon','sao'); ?></label>
        <label style="padding-bottom: 5px; padding-top:0px;font-size: 12px;font-style: italic;"><?php _e('Go to this link for <a target="_blank" href="//fontawesome.io/icons/">Fontawesome icons</a> and copy the class of icon that you need & paste it below.','sao'); ?></label>
        <input type="text" class="widefat" name="<?php echo $this->get_field_name('fontaws'); ?>" id="<?php echo $this->get_field_id('fontaws'); ?>" value="<?php  echo $fontaws; ?>" style="margin-top:5px;">
       </p>

       <p><label for="<?php echo $this->get_field_id( 'iconcolor' ); ?>" style="display:block;"><?php _e( 'Icon Color','sao' ); ?></label>
    <input class="widefat color-picker" id="<?php echo $this->get_field_id( 'iconcolor' ); ?>" name="<?php echo $this->get_field_name( 'iconcolor' ); ?>" type="text" value="<?php echo esc_attr( $iconcolor ); ?>" />
      </p>
		<?php
	}
}
