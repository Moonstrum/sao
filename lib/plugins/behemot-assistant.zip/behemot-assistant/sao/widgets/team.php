<?php
class sao_customizer_team_widget extends WP_Widget {

    function __construct() {
        $widget_ops = array('classname' => 'sao-customizer-team',
            'description' => 'Show your team');
        parent::__construct('sao_customizer_team_widget', __('sao: Team Widget','sao'), $widget_ops);
    }

    function widget($args, $instance) {
        extract($args);

        // widget content
        echo $before_widget;
        $name = isset($instance['name'])?$instance['name']:__('Name','sao');
        $authpic = isset($instance['authpic'])?$instance['authpic']:__('Picture','sao');
				$role = isset($instance['role'])?$instance['role']:__('Role','sao');
        $description = isset($instance['description'])?$instance['description']:__('Description','sao');
        $fontaws1 = isset($instance['fontaws1'])?$instance['fontaws1']:__('fab fa-facebook','sao');
        $fontaws1link = isset($instance['fontaws1link'])?$instance['fontaws1link']:'';
        $fontaws2 = isset($instance['fontaws2'])?$instance['fontaws2']:__('fab fa-twitter-square','sao');
        $fontaws2link = isset($instance['fontaws2link'])?$instance['fontaws2link']:'';
        $fontaws3 = isset($instance['fontaws3'])?$instance['fontaws3']:__('fab fa-pinterest-square','sao');
        $fontaws3link = isset($instance['fontaws3link'])?$instance['fontaws3link']:'';
        $fontaws4 = isset($instance['fontaws4'])?$instance['fontaws4']:__('fab fa-linkedin','sao');
        $fontaws4link = isset($instance['fontaws4link'])?$instance['fontaws4link']:'';
?>

<li class="team-wrap">
   <article class="material-card">
       <h2>
           <span><?php echo $name; ?></span>
           <strong>
               <?php echo $role; ?>
           </strong>
       </h2>
       <div class="mc-content">
           <div class="img-container">
               <img class="img-responsive" src="<?php echo esc_url( $authpic ); ?>" alt="Team Member Image">
           </div>
           <div class="mc-description"><?php echo $description; ?></div>
       </div>
       <a class="mc-btn-action">
           <i class="fas fa-bars"></i>
       </a>
       <div class="mc-footer">
           <a <?php if($fontaws1link != ''){ echo 'href="'. $fontaws1link . '"';}  ?> target="_blank"><i class="<?php echo $fontaws1; ?>"></i></a>
           <a <?php if($fontaws2link != ''){ echo 'href="'. $fontaws3link . '"';}  ?> target="_blank"><i class="<?php echo $fontaws2; ?>"></i></a>
           <a <?php if($fontaws3link != ''){ echo 'href="'. $fontaws3link . '"';}  ?> target="_blank"><i class="<?php echo $fontaws3; ?>"></i></a>
           <a <?php if($fontaws4link != ''){ echo 'href="'. $fontaws4link . '"';}  ?> target="_blank"><i class="<?php echo $fontaws4; ?>"></i></a>
       </div>
   </article>
</li>

<?php
        echo $after_widget;

    }

    function update($new_instance, $old_instance) {
        $instance = $old_instance;
        $instance['authpic'] = $new_instance['authpic'];
        $instance['name'] = strip_tags( $new_instance['name'] );
				$instance['role'] = $new_instance['role'];
        $instance['description'] = $new_instance['description'];
        $instance['fontaws1'] = $new_instance['fontaws1'];
        $instance['fontaws1link'] = $new_instance['fontaws1link'];
        $instance['fontaws2'] = $new_instance['fontaws2'];
        $instance['fontaws2link'] = $new_instance['fontaws2link'];
        $instance['fontaws3'] = $new_instance['fontaws3'];
        $instance['fontaws3link'] = $new_instance['fontaws3link'];
        $instance['fontaws4'] = $new_instance['fontaws4'];
        $instance['fontaws4link'] = $new_instance['fontaws4link'];
        return $instance;
    }

    function form($instance) {
         if( $instance) {
        $name = esc_attr($instance['name']);
        $authpic = strip_tags($instance['authpic']);
        $role = $instance['role'];
        $description = $instance['description'];
        $fontaws1 = $instance['fontaws1'];
        $fontaws1link = $instance['fontaws1link'];
        $fontaws2 = $instance['fontaws2'];
        $fontaws2link = $instance['fontaws2link'];
        $fontaws3 = $instance['fontaws3'];
        $fontaws3link = $instance['fontaws3link'];
        $fontaws4 = $instance['fontaws4'];
        $fontaws4link = $instance['fontaws4link'];
    } else {
        $name = '';
        $authpic = '';
				$role = '';
        $description = '';
        $fontaws1 = 'fab fa-facebook';
        $fontaws1link = '';
        $fontaws2 = 'fab fa-twitter-square';
        $fontaws2link = '';
        $fontaws3 = 'fab fa-pinterest-square';
        $fontaws3link = '';
        $fontaws4 = 'fab fa-linkedin';
        $fontaws4link = '';
    }

    ?>
<div class="clearfix"></div>
        <label for="<?php echo $this->get_field_id('authpic'); ?>"><?php _e('Member Image','sao'); ?></label>
                <?php
            if ( isset($instance['authpic']) && $instance['authpic'] != '' ) :
                echo '<img class="custom_media_image" src="' . $instance['authpic'] . '" style="margin:0;padding:0;max-width:100px;float:left;display:inline-block" /><br />';
            endif;
        ?>
        <label style="padding-bottom: 5px; padding-top:0px;font-size: 12px;font-style: italic;"><?php _e('Recommende size for team member picture is 670 x 670 px','sao'); ?></label>
        <input type="text" class="widefat custom_media_url" name="<?php echo $this->get_field_name('authpic'); ?>" id="<?php echo $this->get_field_id('authpic'); ?>" value="<?php  echo $authpic; ?>" style="margin-top:5px;">
        <input type="button" class="button button-primary custom_media_button" id="<?php echo $this->get_field_id('authpic'); ?>_button" name="<?php echo $this->get_field_name('authpic'); ?>" value="Upload Image" style="margin-top:5px;" />

        <p><label for="<?php echo $this->get_field_id('name'); ?>"><?php _e('Team Member Name','sao'); ?></label>
        <input type="text" class="widefat" name="<?php echo $this->get_field_name('name'); ?>" id="<?php echo $this->get_field_id('name'); ?>" value="<?php  echo $name; ?>">
        </p>

				<p><label for="<?php echo $this->get_field_id('role'); ?>"><?php _e('Role Description','sao'); ?></label>
        <input type="text" class="widefat" name="<?php echo $this->get_field_name('role'); ?>" id="<?php echo $this->get_field_id('role'); ?>" value="<?php  echo $role; ?>">
        </p>

        <p><label for="<?php echo $this->get_field_id('description'); ?>"><?php _e('Description','sao'); ?></label>
        <textarea  name="<?php echo $this->get_field_name('description'); ?>" id="<?php echo $this->get_field_id('description'); ?>"  class="widefat" ><?php  echo $description; ?></textarea>
        </p>

      <label style="padding-bottom: 5px; padding-top:0px;font-size: 12px;font-style: italic;"><?php _e('Go to this link for <a target="_blank" href="//fontawesome.io/icons/">Fontawesome icons</a> and copy the class of icon that you need & paste it below.','sao'); ?></label>

      <p>
       <label for="<?php echo $this->get_field_id('fontaws1'); ?>"><?php _e('Social icon 1','sao'); ?></label>
       <input type="text" class="widefat" name="<?php echo $this->get_field_name('fontaws1'); ?>" id="<?php echo $this->get_field_id('fontaws1'); ?>" value="<?php  echo $fontaws1; ?>" style="margin-top:5px;">
       <input type="text" class="widefat" name="<?php echo $this->get_field_name('fontaws1link'); ?>" id="<?php echo $this->get_field_id('fontaws1link'); ?>" value="<?php  echo $fontaws1link; ?>" placeholder="https://"   style="margin-top:5px;">
      </p>
      <p>
       <label for="<?php echo $this->get_field_id('fontaws2'); ?>"><?php _e('Social icon 2','sao'); ?></label>
       <input type="text" class="widefat" name="<?php echo $this->get_field_name('fontaws2'); ?>" id="<?php echo $this->get_field_id('fontaws2'); ?>" value="<?php  echo $fontaws2; ?>" style="margin-top:5px;">
       <input type="text" class="widefat" name="<?php echo $this->get_field_name('fontaws2link'); ?>" id="<?php echo $this->get_field_id('fontaws2link'); ?>" value="<?php  echo $fontaws2link; ?>" placeholder="https://"   style="margin-top:5px;">
      </p>
      <p>
       <label for="<?php echo $this->get_field_id('fontaws3'); ?>"><?php _e('Social icon 3','sao'); ?></label>
       <input type="text" class="widefat" name="<?php echo $this->get_field_name('fontaws3'); ?>" id="<?php echo $this->get_field_id('fontaws3'); ?>" value="<?php  echo $fontaws3; ?>" style="margin-top:5px;">
       <input type="text" class="widefat" name="<?php echo $this->get_field_name('fontaws3link'); ?>" id="<?php echo $this->get_field_id('fontaws3link'); ?>" value="<?php  echo $fontaws3link; ?>" placeholder="https://"   style="margin-top:5px;">
      </p>
      <p>
        <label for="<?php echo $this->get_field_id('fontaws4'); ?>"><?php _e('Social icon 4','sao'); ?></label>
       <input type="text" class="widefat" name="<?php echo $this->get_field_name('fontaws4'); ?>" id="<?php echo $this->get_field_id('fontaws4'); ?>" value="<?php  echo $fontaws4; ?>" style="margin-top:5px;">
       <input type="text" class="widefat" name="<?php echo $this->get_field_name('fontaws4link'); ?>" id="<?php echo $this->get_field_id('fontaws4link'); ?>" value="<?php  echo $fontaws4link; ?>" placeholder="https://"   style="margin-top:5px;">
      </p>


        <?php
    }
}
