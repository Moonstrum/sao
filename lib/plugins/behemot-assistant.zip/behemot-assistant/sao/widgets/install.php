<?php
add_action('widgets_init', 'sao_register_widgets');
function sao_register_widgets(){
  register_widget('sao_customizer_services_widget');
	register_widget('sao_customizer_team_widget');
	register_widget('sao_customizer_testimonial_widget');
	register_widget('sao_customizer_partners_widget');
}
  ?>
