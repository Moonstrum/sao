<?php
class sao_customizer_partners_widget extends WP_Widget {

    function __construct() {
        $widget_ops = array('classname' => 'sao-customizer-partners',
            'description' => 'Show your partners');
        parent::__construct('sao_customizer_partners_widget', __('sao : Partners Widget','sao'), $widget_ops);
    }

    function widget($args, $instance) {
        extract($args);
        // widget content
        echo $before_widget;

        $partnerlogo = isset($instance['partnerlogo'])?$instance['partnerlogo']:'';
?>

        <li><div class="partners-image wow fadeInLeft" data-wow-delay="0s">
        <?php  if($partnerlogo!=''){ ?>
         <img src="<?php echo $partnerlogo; ?>">
         <?php } ?>
        </div>
        </li>

<?php
        echo $after_widget;

    }

    function update($new_instance, $old_instance) {
        $instance = $old_instance;
        $instance['partnerlogo'] = $new_instance['partnerlogo'];
        return $instance;
    }

    function form($instance) {
        if( $instance) {
        $authpic = strip_tags($instance['partnerlogo']);
    } else {
        $authpic = '';
    }
    ?>
        <div class="clearfix"></div>
        <label for="<?php echo $this->get_field_id('partnerlogo'); ?>"><?php _e('Partner Logo','sao'); ?></label>
                <?php
            if ( isset($instance['partnerlogo']) && $instance['partnerlogo'] != '' ) :
                echo '<img class="custom_media_image" src="' . $instance['partnerlogo'] . '" style="margin:0;padding:0;max-width:100px;float:left;display:inline-block" /><br />';
            endif;
        ?>
        <input type="text" class="widefat custom_media_url" name="<?php echo $this->get_field_name('partnerlogo'); ?>" id="<?php echo $this->get_field_id('partnerlogo'); ?>" value="<?php  echo $instance['partnerlogo']; ?>" style="margin-top:5px;">
        <input type="button" class="button button-primary custom_media_button" id="<?php echo $this->get_field_id('partnerlogo'); ?>_button" name="<?php echo $this->get_field_name('partnerlogo'); ?>" value="Upload Image" style="margin-top:5px;" />

        <?php
    }
}
