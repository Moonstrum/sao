<?php
function sao_create_post_type() {
// set up labels
$labels = array(
  'name' => 'Projects',
    'singular_name' => 'Project',
    'add_new' => 'Add New Project',
    'add_new_item' => 'Add New Project',
    'edit_item' => 'Edit Project',
    'new_item' => 'New Project',
    'all_items' => 'All Project',
    'view_item' => 'View Project',
    'search_items' => 'Search Project',
    'not_found' =>  'No Project Found',
    'not_found_in_trash' => 'No Projects found in Trash',
    'parent_item_colon' => '',
    'menu_name' => 'Projects',
  );
  //register post type
register_post_type( 'project', array(
  'labels' => $labels,
  'has_archive' => true,
  'public' => true,
  'supports' => array( 'title', 'editor', 'excerpt', 'custom-fields', 'thumbnail','page-attributes' ),
  'taxonomies' => array( 'post_tag', 'category' ),
  'exclude_from_search' => false,
  'capability_type' => 'post',
  'rewrite' => array( 'slug' => 'projects' ),
  )
);
}
add_action( 'init', 'sao_create_post_type' );
 ?>
