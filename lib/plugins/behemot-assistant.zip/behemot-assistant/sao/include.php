<?php
    include_once( plugin_dir_path(__FILE__) . 'cpt/project.php' );
		include_once( plugin_dir_path(__FILE__) . 'widgets/team.php' );
		include_once( plugin_dir_path(__FILE__) . 'widgets/testimonials.php' );
		include_once( plugin_dir_path(__FILE__) . 'widgets/services.php' );
    include_once( plugin_dir_path(__FILE__) . 'widgets/partners.php' );
    include_once( plugin_dir_path(__FILE__) . 'widgets/install.php' );
		include_once( plugin_dir_path(__FILE__) . 'shortcodes/shortcodes.php' );
?>
