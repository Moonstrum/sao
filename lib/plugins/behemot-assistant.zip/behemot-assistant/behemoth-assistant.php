<?php
/*
 Plugin Name: Behemoth Assistant
 description: Behemoth themes assistant plugin
 Version: 1.0
 Author: Behemoth Themes
 License: GPL2
 */

   if ( ! defined( 'ABSPATH' ) ) exit;

   // Version constant for easy CSS refreshes
    define('BEHEMOTH_ASSISTANT_VERSION', '1.0');
    define('BEHEMOTH_ASSISTANT_PLUGIN_URL', plugin_dir_url(__FILE__));

    add_action('after_setup_theme', 'behemoth_assistant_load_plugin');
    function behemoth_assistant_load_plugin() {
      include_once( plugin_dir_path(__FILE__) . 'sao/include.php' );
      }

 ?>
